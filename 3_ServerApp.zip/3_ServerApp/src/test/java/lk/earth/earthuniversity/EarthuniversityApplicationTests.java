package lk.earth.earthuniversity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EarthuniversityApplicationTests {

	@Test
	void contextLoads() {
	}

}
