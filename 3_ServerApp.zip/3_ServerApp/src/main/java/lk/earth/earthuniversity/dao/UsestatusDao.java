package lk.earth.earthuniversity.dao;


import lk.earth.earthuniversity.entity.Usestatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsestatusDao extends JpaRepository<Usestatus,Integer> {

}

