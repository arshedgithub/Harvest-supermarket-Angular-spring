package lk.earth.earthuniversity.dao;

import lk.earth.earthuniversity.entity.Emptype;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmptypeDao extends JpaRepository<Emptype,Integer> {
}
