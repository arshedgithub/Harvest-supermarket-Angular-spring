package lk.earth.earthuniversity.dao;

import lk.earth.earthuniversity.entity.Designation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DesignationDao extends JpaRepository<Designation,Integer> {

}

