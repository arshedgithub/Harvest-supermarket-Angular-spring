package lk.earth.earthuniversity.dao;

import lk.earth.earthuniversity.entity.Unittype;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UnittypeDao extends JpaRepository<Unittype,Integer> {
}
