package lk.earth.earthuniversity.dao;

import lk.earth.earthuniversity.entity.Emptype;
import lk.earth.earthuniversity.entity.Opetype;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OpetypeDao extends JpaRepository<Opetype,Integer> {
}
