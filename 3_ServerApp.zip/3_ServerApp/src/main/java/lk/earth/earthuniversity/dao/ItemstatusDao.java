package lk.earth.earthuniversity.dao;

import lk.earth.earthuniversity.entity.Itemstatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemstatusDao extends JpaRepository<Itemstatus,Integer> {

}

