package lk.earth.earthuniversity.dao;


import lk.earth.earthuniversity.entity.Subcategory;
import org.springframework.data.jpa.repository.JpaRepository;


public interface SubcategoryDao extends JpaRepository<Subcategory,Integer> {

}
