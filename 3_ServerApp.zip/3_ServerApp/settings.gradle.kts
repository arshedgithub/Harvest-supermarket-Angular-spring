rootProject.name = "earthuniversity"
